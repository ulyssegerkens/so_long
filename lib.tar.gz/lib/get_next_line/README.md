This is an exported version of Get Next Line.
Change logs:
- include, obj directory
- only bonus version
- get_next_line nor return a status and put the line in a buffer